-- ==============================================================================
-- Coripet RVM Predictor: Hidden Machines Tables Dump for MariaDB
-- Database: coripet_rvm
-- Compatible with Plesk MariaDB 10.6+ & phpMyAdmin
-- ==============================================================================

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET NAMES utf8mb4;

-- -------------------------------------------------------------
-- Table structure for `hidden_spl_machines`
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `hidden_spl_machines` (
  `punto_fisico` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cap` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comune` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provincia` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regione` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `machine_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `predicted_bottles` float DEFAULT 0,
  `predicted_month` int(11) DEFAULT 0,
  `volume_tier` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reward_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dt_fine_sop` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden_at` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`punto_fisico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------
-- Table structure for `hidden_pot_machines`
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `hidden_pot_machines` (
  `punto_fisico` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `store_name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cap` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comune` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provincia` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regione` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `machine_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `predicted_bottles` float DEFAULT 0,
  `predicted_month` int(11) DEFAULT 0,
  `volume_tier` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reward_type` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dt_fine_sop` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden_at` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`punto_fisico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;

